The demo scene makes use of Unity Post Processing and Unity Standard Assets.
Add water prefabs to demo scene at: Standard Assets > Environment > Water > Water > Prefabs > WaterProDaytime

Thanks.