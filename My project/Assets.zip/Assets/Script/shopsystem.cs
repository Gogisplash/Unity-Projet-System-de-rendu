using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using UnityEngine;

public class shopsystem : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //money = GetComponent<InventoryManager>();   
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
